# TwinCAT Sorting Cell Simulation

## 1. Project Summary
This project simulates a small industrial sorting cell using TwinCAT 3 PLC logic. It includes conveyor control, part detection, reject handling, manual mode, fault handling, and reset behavior.

**Target role keywords:** TwinCAT 3, PLC, structured text, state machine, EtherCAT, automation, HMI, fault handling, commissioning.

## 2. Problem Statement
Factories need predictable sorting logic that can handle normal production, manual override, sensor faults, actuator faults, and emergency-stop recovery. This project demonstrates the control logic and documentation expected in entry-level automation roles.

## 3. System Architecture
Add a diagram showing:
- Start/stop/reset buttons
- Conveyor motor
- Photoelectric sensor
- Reject actuator
- Part counter
- Fault and emergency-stop signals
- HMI/status display

**Screenshot to add:** `docs/architecture_diagram.png`

## 4. I/O Table
| Signal | Type | Address | Description |
|---|---|---|---|
| StartButton | Digital input | `%I*` | Starts AutoRun when system is ready |
| StopButton | Digital input | `%I*` | Stops conveyor and returns to Idle |
| ResetButton | Digital input | `%I*` | Clears recoverable faults |
| PhotoSensor | Digital input | `%I*` | Detects part at inspection point |
| RejectActuator | Digital output | `%Q*` | Rejects failed part |
| ConveyorMotor | Digital output | `%Q*` | Runs conveyor in AutoRun/manual mode |
| FaultLight | Digital output | `%Q*` | Shows system fault |

## 5. PLC State Machine
Document these states:
- Idle
- Homing
- AutoRun
- Reject
- ManualJog
- Fault
- Reset
- EmergencyStop

**Screenshot to add:** `docs/state_machine.png`

## 6. Control Logic
Explain:
- How AutoRun starts
- How a part is detected
- How the reject actuator is triggered
- How faults are detected
- How reset returns the system to a safe state

## 7. Test Cases
| Test | Input Condition | Expected Result | Pass/Fail |
|---|---|---|---|
| Normal start | Start pressed, no faults | Conveyor runs | |
| Part detected | Sensor pulse received | Counter increments | |
| Reject part | Reject condition true | Actuator fires | |
| Missing sensor | No sensor pulse within timer | Fault state | |
| Emergency stop | E-stop active | Outputs disabled | |
| Reset | Reset after fault cleared | System returns to Idle | |

## 8. Screenshots / Demo Proof
Add:
- TwinCAT project tree
- Structured text state-machine code
- Watch table during AutoRun
- Watch table during Fault
- HMI/status screen
- 1-2 minute demo video link

## 9. What I Learned
Write 3-5 bullets:
- Designed PLC logic as a state machine instead of loose conditions.
- Documented I/O mapping and test cases for maintainability.
- Practiced fault handling and reset behavior used in industrial automation.

## 10. Next Improvements
- Add real HMI screens.
- Connect to Factory I/O or a physical PLC training kit.
- Add production counters and OEE-style summary.
- Add alarm history and fault timestamps.
