# ROS2 Warehouse AMR Simulation

## 1. Project Summary
This project simulates an autonomous mobile robot workflow in a warehouse environment using ROS2, Gazebo, RViz, and Nav2. The robot navigates between pickup and drop-off points and logs mission status.

**Target role keywords:** ROS2, Gazebo, RViz, Nav2, Python, robot simulation, AMR, path planning, SLAM, robotics software.

## 2. Problem Statement
Warehouse automation teams need robots that can move between defined locations, recover from blocked paths, and report task status clearly. This project demonstrates a basic AMR software workflow with reproducible setup and visual proof.

## 3. Architecture
Add a diagram showing:
- Gazebo simulation world
- Robot model / URDF
- Map and localization
- Nav2 stack
- Python task dispatcher node
- Mission logger

**Screenshot to add:** `docs/ros2_node_graph.png`

## 4. Tools Used
- ROS2: [version]
- Gazebo: [version]
- RViz: [version]
- Nav2: [version]
- Python: [version]
- OS: [Ubuntu version]

## 5. How To Run
```bash
# 1. Clone repository
git clone [repository-url]
cd [repository-name]

# 2. Install dependencies
rosdep install --from-paths src --ignore-src -r -y

# 3. Build workspace
colcon build
source install/setup.bash

# 4. Launch simulation
ros2 launch [package_name] warehouse_sim.launch.py

# 5. Start task dispatcher
ros2 run [package_name] task_dispatcher.py
```

## 6. Mission Workflow
| Step | Robot Action | Expected Output |
|---|---|---|
| 1 | Load map | Warehouse map visible in RViz |
| 2 | Navigate to pickup | Robot reaches pickup zone |
| 3 | Wait / simulate loading | Status changes to Loaded |
| 4 | Navigate to drop-off | Robot reaches drop-off zone |
| 5 | Log mission result | Terminal prints success/failure |

## 7. Screenshots / Demo Proof
Add:
- Gazebo warehouse world
- RViz planned path
- ROS2 node graph
- Terminal mission logs
- Failed path / recovery case
- Short demo video or GIF

## 8. Testing
| Test | Scenario | Expected Result | Evidence |
|---|---|---|---|
| Normal mission | Pickup to drop-off | Robot reaches goal | Screenshot/video |
| Blocked route | Obstacle in path | Nav2 replans or fails safely | RViz screenshot |
| Invalid goal | Goal outside map | Dispatcher logs failure | Terminal log |

## 9. What I Learned
- Built a reproducible ROS2 simulation workflow.
- Used RViz and Gazebo to show robot behavior visually.
- Logged mission status so the project is understandable to recruiters.

## 10. Next Improvements
- Add multi-goal task queue.
- Add battery or charging logic.
- Add object detection or QR marker localization.
- Add Docker setup for easier reproduction.
