# Embedded Predictive Maintenance Sensor Node

## 1. Project Summary
This project uses an STM32 or ESP32-based sensor node to read vibration and temperature data, flag abnormal readings, and export logs for simple maintenance analysis.

**Target role keywords:** embedded C, ESP32, STM32, sensor integration, UART, I2C, SPI, MQTT, firmware testing, condition monitoring, industrial IoT.

## 2. Problem Statement
Maintenance teams need early warning signs for abnormal machine behavior. This project demonstrates a small embedded system that captures sensor data, applies simple threshold logic, and produces logs that can be reviewed.

## 3. Hardware
| Component | Purpose | Notes |
|---|---|---|
| ESP32 / STM32 | Main controller | Replace with exact board |
| Vibration sensor | Machine condition signal | Replace with exact sensor |
| Temperature sensor | Thermal condition signal | Replace with exact sensor |
| Power supply | Stable power | Mention voltage/current |
| Breadboard / PCB | Prototype wiring | Add wiring photo |

## 4. Firmware Architecture
Add a diagram showing:
- Sensor read loop
- Filtering / moving average
- Threshold comparison
- Serial or MQTT output
- Error handling
- CSV logging on laptop

**Screenshot to add:** `docs/firmware_flowchart.png`

## 5. Data Format
Example CSV:
```csv
timestamp,temperature_c,vibration_raw,vibration_avg,alert
2026-06-27 10:00:00,32.4,421,398,0
2026-06-27 10:00:05,35.1,701,620,1
```

## 6. How To Run
```bash
# 1. Flash firmware
[add IDE or CLI steps]

# 2. Start serial/MQTT logger
python logger.py --port COM3 --baud 115200

# 3. Generate test data
[describe normal and abnormal tests]
```

## 7. Test Cases
| Test | Input | Expected Output | Evidence |
|---|---|---|---|
| Normal reading | Stable sensor values | alert = 0 | CSV log |
| High vibration | Shake sensor / simulated high value | alert = 1 | Terminal screenshot |
| Missing sensor | Disconnect sensor | Error code logged | Serial log |
| Long run | 30-minute run | No crash, continuous log | CSV file |

## 8. Screenshots / Demo Proof
Add:
- Wiring diagram
- Photo of prototype
- Firmware code snippet
- Serial monitor output
- CSV chart
- Alert case screenshot

## 9. What I Learned
- Integrated sensor readings into firmware logic.
- Created testable fault and threshold behavior.
- Documented hardware, firmware, and data output for engineering review.

## 10. Next Improvements
- Add MQTT dashboard.
- Add enclosure and cleaner wiring.
- Add calibration routine.
- Add FreeRTOS tasks for sampling and communication.
